Changelog
---------

#### New from v1.1.2 <br />
(21/07/2017) <br />
-Fix a dot sometimes appearing at the beginning of a line, thanks [@ninadmg](https://github.com/ninadmg)

#### New from v1.1.1 <br />
(30/05/2017) <br />
-Async read and write serializable in Sample <br />
-Added clear button in Activities <br />
-Added GitHub link in Activities <br />
-Added clearHistory() method in FreeDrawView to remove all history <br />
-Added clearDraw() method in FreeDrawView to remove all drawn paths <br />
-Added clearDrawAndHistory() method in FreeDrawView to remove both drawn paths and history <br />
-Added getPathCount(boolean includeCurrentlyDrawingPath) to get the current number of drawn lines <br />

#### New from v1.1.0 <br />
(24/05/2017) <br />
-Added option to save and restore the view state #8 <br />

#### New from v1.0.2: <br />
(02/02/2017) <br />
-Fix crash if no PathDrawnListener has been set <br />

#### New from v1.0.1: <br />
(23/01/2017) <br />
-Added onPathStart to be notified when a user starts drawing <br />

#### New from v1.0.0: <br />
(23/12/2016) <br />
-Initial release